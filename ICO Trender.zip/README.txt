ICO Trender
===========

ICO Trender is an ICO Trending Bot. which trend your project to #1 on PINKSALE. 
This Software only support PINKSALE for now, with the support of the public and buyers other Platforms will be added in the future.
such as DEX Tool and more.


How to install
==============

* Click on ICOTrender.exe File
* Look into "Config" Folder you will find three files "proxies.txt", "settings.yaml" and "user_agent.txt"
* This Software needs active sock5 proxies to work perfectly. There is no proxies limit.
* This Software can run multiple times at once, if your pc has high performance capability.


Settings.yaml
=============

* "click" is the second set per link click
* "wait" is the second set per wait
* "limit" is the limit visit per browser, default is set to "1"
* "link" is the link of the Project
* "firefox", "chrome", "edge", "opera", "brave" - Browser Path from PC Drive


Features
========

* Proxies Checker, select the good and delete the bad
* Clicks All Social Media/Network Links
* Clicks Presale Address Links
* Clicks Token / Contract Links
* Clicks Pancakeswap Links
* Scrolling UP / DOWN Page
* Time Spent on WebPage is configurable in "settings.yaml"


Contact
=======

Author: Oliver Walker

Telegram: oliverwalkerjp

Jabber: oliverwalker@xmpp.jp

Free Trial: run 10 Times
Price: $500

